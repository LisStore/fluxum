const express = require("express");
const mysql = require("mysql2/promise");
const cors = require("cors");

const app = express();
const port = 3000;
app.use(cors());
app.use(express.json());

const db = mysql.createPool({
    host: "177.54.147.182", 
    user: "praiagr1_praiagr1", 
    password: ",l8=D+GssBxu", 
    database: "praiagr1_venezza_delivery",
    connectionLimit: 10
});

app.get('/lanches', async (req, res) => {
  const [dados] = await db.query("SELECT * FROM lanches");
  res.json(dados);
});


app.get('/fetchLanches', async (req, res) => {
  const [dados] = await db.query("SELECT * FROM lanches WHERE tipo_lanche=?", `${req}`);
  res.json(dados);
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
});