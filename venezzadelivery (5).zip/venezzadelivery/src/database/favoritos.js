async function atualizandoFavoritos(){
    const response = await fetch('http://localhost:3000/lanchesfavoritos');
    const series = await response.json();

    console.log(series)

    const updateLanche = document.getElementById("cardsLanches");

    updateLanche.innerHTML = series.map(c => `
        <div class="card">
            <div class="imges">
                <img src="${c.image_link_lanche}" alt="">
                ${c.favorito == 0 ? '' : '<span class="tag">FAVORITA</span>'}
            </div>
            <div class="top">
                <h2>${c.nome}</h2>
                <span>R$ ${c.valor}</span>
            </div>
            <p>${c.descricao}</p>
            <button><i class="bi bi-plus"></i> Adicionar ao Carrinho</button>
        </div>
    `).join("");
}

atualizandoFavoritos();