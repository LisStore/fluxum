document.getElementById("dataMovies").addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("nomeLanche").value; // nome do filme
  const categoria = document.getElementById("tipoLanche").value; // link embed inoutube
  const preco = document.getElementById("preco").value; // tipo filme ou serie
  const descricao = document.getElementById("descricao").value; // genero
  const imagem = document.getElementById("file").value; // descrição
''
  const response = await fetch(`http://localhost:3000/sendLanche`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, categoria, preco, descricao, imagem })
  });

  if (response.ok) {
    alert(`${name} cadastrado com sucesso!`);
    e.currentTarget.reset();
  } else {
    alert(`Erro ao cadastrar o lanche.`);
  }
});